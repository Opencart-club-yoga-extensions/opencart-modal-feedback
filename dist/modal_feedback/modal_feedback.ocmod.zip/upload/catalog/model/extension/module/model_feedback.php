<?php
class ControllerExtensionModuleModalFeedback extends Controller {

	private $error = array();

	public function index(){
		$data = array();

    	if (!$this->config->get('module_modal_feedback_status')) return false;

		$this->load->language('extension/module/modal_feedback');
		$data['api_key'] = $this->config->get('module_modal_feedback_api_key');
		$data['action'] = $this->url->link('extension/module/modal_feedback/send');
		$data['feedback_form'] = $this->load->view('extension/module/modal_feedback', $data);
		return $this->load->view('extension/module/modal_feedback_modal', $data);
	}

  	public function send(){

		$json = array();

		$this->load->language('extension/module/modal_feedback');

    	if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			
			$this->load->model('extension/module/modal_feedback');
			$data = [];
			foreach ($this->request->post as $key => $value) {
				$data[$key] = $this->db->escape($value);
			}
			$this->model_extension_module_modal_feedback->createNewFeedback($data);

			$json['success'] = $this->language->get('text_success');
		} else {
			$json['error'] = $this->error;
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));

  	}

  	protected function validate() {

		if ((utf8_strlen($this->request->post['firstname']) < 3) || (utf8_strlen($this->request->post['firstname']) > 32)) {
			$this->error['firstname'] = $this->language->get('error_firstname');
    	}

    	if ((utf8_strlen($this->request->post['telephone']) < 9) || (utf8_strlen($this->request->post['telephone']) > 32)) {
			$this->error['telephone'] = $this->language->get('error_telephone');
		}

		if (!filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL)) {
			$this->error['email'] = $this->language->get('error_email');
		}

		if (!isset($this->request->post['agree'])) {
			$this->error['agree'] = $this->language->get('error_agree');
		}

		return !$this->error;
	}

	protected function mail($data){
		$mail = new Mail($this->config->get('config_mail_engine'));
		$mail->parameter = $this->config->get('config_mail_parameter');
		$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
		$mail->smtp_username = $this->config->get('config_mail_smtp_username');
		$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
		$mail->smtp_port = $this->config->get('config_mail_smtp_port');
		$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

		$mail->setTo($this->config->get('config_email'));
		$mail->setFrom($this->config->get('config_email'));
		$mail->setReplyTo($data['email']);
		$mail->setSender(html_entity_decode($data['firstname'], ENT_QUOTES, 'UTF-8'));
		$mail->setSubject(html_entity_decode(sprintf($this->language->get('email_subject'), $data['firstname']), ENT_QUOTES, 'UTF-8'));
		$mail->setHtml($this->load->view('extension/module/modal_feedback_mail', $data));
		$mail->send();
	}

}